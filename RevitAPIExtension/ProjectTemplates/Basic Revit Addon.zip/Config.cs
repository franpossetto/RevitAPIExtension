﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal static class Config
    {
        //Full Class Name
        public const string FULL_CLASS_NAME = "$safeprojectname$.ExternalCommand";
        public const string CLASS_NAME = "ExternalCommand";


        //Revit Versions
        public const string RVT_2020 = "2020";
        public const string RVT_2019 = "2019";
        public const string RVT_2018 = "2018";
        public const string RVT_2017 = "2017";
        
    }

    // Post-Build Commands
    // copy "$(TargetDir)"."" "$(AppData)\Autodesk\Revit\Addins\2019\"
}
