﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;

namespace $safeprojectname$
{
    class ExternalApplication : IExternalApplication
    {
        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application)
        {

            /// <summary>
            /// Create a new Tab on Ribbon Bar.
            /// </summary>
            const string RIBBON_TAB = Config.CLASS_NAME + " TAB";
            Ribbon.CreateRibbonTab(application, RIBBON_TAB);

            /// <summary>
            /// Create a new Panel on Ribbon Tab.
            /// </summary>
            const string RIBBON_PANEL = Config.CLASS_NAME + " PANEL";
            RibbonPanel ribbonPanel = Ribbon.CreateRibbonPanel(application, RIBBON_PANEL, RIBBON_TAB);

            /// <summary>
            /// Generic ICON.
            /// </summary>
            System.Drawing.Bitmap ico = Properties.Resources.icon;
            System.Windows.Media.Imaging.BitmapSource icon = Ribbon.Icon(ico);
           
            /// <summary>
            /// Create new Buttons on Panel.
            /// </summary>
            const string PUSH_BUTTON_NAME_1 = "Button 1";
            const string PUSH_BUTTON_DESC_1 = "This is the Button 1";
            PushButtonData pushDataButton1 = Ribbon.CreatePushButtonData(PUSH_BUTTON_NAME_1, PUSH_BUTTON_DESC_1, Config.FULL_CLASS_NAME);
            pushDataButton1.LargeImage = icon;

            /// <summary>
            /// Create new Buttons on Panel.
            /// </summary>
            const string PUSH_BUTTON_NAME_2 = "Button 2";
            const string PUSH_BUTTON_DESC_2 = "This is the Button 2";
            PushButtonData pushDataButton2 = Ribbon.CreatePushButtonData(PUSH_BUTTON_NAME_2, PUSH_BUTTON_DESC_2, Config.FULL_CLASS_NAME);
            pushDataButton2.LargeImage = icon;

            /// <summary>
            /// Create new Buttons on Panel.
            /// </summary>
            const string PUSH_BUTTON_NAME_3 = "Button 3";
            const string PUSH_BUTTON_DESC_3 = "This is the Button 3";
            PushButtonData pushDataButton3 = Ribbon.CreatePushButtonData(PUSH_BUTTON_NAME_3, PUSH_BUTTON_DESC_3, Config.FULL_CLASS_NAME);
            pushDataButton3.LargeImage = icon;

            Ribbon.AddPushButton(ribbonPanel, pushDataButton1);
            Ribbon.AddPushButton(ribbonPanel, pushDataButton2);
            Ribbon.AddPushButton(ribbonPanel, pushDataButton3);

            return Result.Succeeded;



        }
    }
}
